class Produto {
  constructor (codigo, descricao, valor)
  {
    this.codigo = codigo;
    this.descricao = descricao;
    this.valor = valor;
  }
}