window.onload = (event) => {
  if (event.keyCode == 13) {
    event.preventDefault();
    alert("Apertou a tecla");
  }
};
